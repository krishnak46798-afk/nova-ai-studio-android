package ai.nova.studio;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
